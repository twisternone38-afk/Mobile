package com.example.mobilegameemulator;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final int PICK_ZIP = 41;
    private WebView web;
    private FrameLayout root, overlay;
    private TextView status;
    private File gamesDir;
    private final Set<String> pressed = new HashSet<>();
    private float mouseX = 0.5f, mouseY = 0.5f;
    private float lastX, lastY;
    private boolean dragging = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        gamesDir = new File(getFilesDir(), "games");
        gamesDir.mkdirs();
        buildUi();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildUi() {
        root = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(18,20,28));
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));

        overlay = new FrameLayout(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        showWelcome();
    }
    private void showWelcome() {
        overlay.removeAllViews();
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER); panel.setPadding(28,24,28,24); panel.setBackground(bg(0xEE171B29,28));
        TextView title = text("MOBILE GAME EMULATOR", 24, Color.WHITE);
        TextView sub = text("Запускайте HTML5-игры из ZIP на Android", 14, 0xFFB8C0D8);
        Button load = new Button(this); load.setText("＋  ЗАГРУЗИТЬ ZIP");
        load.setTextColor(Color.WHITE); load.setBackground(bg(0xFF596BFF,18)); load.setOnClickListener(v -> pickZip());
        TextView hint = text("В архиве должен быть index.html или другая HTML-страница", 12, 0xFFB8C0D8);
        panel.addView(title); panel.addView(sub);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(260,58); lp.topMargin=24; lp.bottomMargin=12;
        panel.addView(load,lp); panel.addView(hint);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        p.setMargins(24,24,24,24); overlay.addView(panel,p);
    }
    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip","application/x-zip-compressed","application/octet-stream"});
        startActivityForResult(i,PICK_ZIP);
    }
    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==PICK_ZIP && result==RESULT_OK && data!=null) {
            Uri uri=data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch(Exception ignored) {}
            new Thread(() -> {
                try {
                    File dest = new File(gamesDir,"current");
                    deleteTree(dest); dest.mkdirs();
                    unzip(uri,dest);
                    File html=findHtml(dest);
                    runOnUiThread(() -> {
                        if(html==null) { showWelcome(); Toast.makeText(this,"В ZIP не найден HTML-файл",Toast.LENGTH_LONG).show(); }
                        else launchGame(html);
                    });
                } catch(Exception e) {
                    runOnUiThread(() -> Toast.makeText(this,"Ошибка ZIP: "+e.getMessage(),Toast.LENGTH_LONG).show());
                }
            }).start();
        }
    }
    private void unzip(Uri uri, File dest) throws Exception {
        try(InputStream in=getContentResolver().openInputStream(uri); ZipInputStream zis=new ZipInputStream(new BufferedInputStream(in))) {
            ZipEntry entry;
            byte[] buf=new byte[8192];
            while((entry=zis.getNextEntry())!=null) {
                File out=new File(dest,entry.getName());
                String rootPath=dest.getCanonicalPath()+File.separator;
                if(!out.getCanonicalPath().startsWith(rootPath)) throw new SecurityException("Недопустимый путь в ZIP");
                if(entry.isDirectory()) out.mkdirs();
                else {
                    File parent=out.getParentFile(); if(parent!=null) parent.mkdirs();
                    try(FileOutputStream fos=new FileOutputStream(out)) {
                        int n; while((n=zis.read(buf))>0) fos.write(buf,0,n);
                    }
                }
                zis.closeEntry();
            }
        }
    }
    private File findHtml(File dir) {
        File direct=new File(dir,"index.html"); if(direct.exists()) return direct;
        ArrayList<File> found=new ArrayList<>();
        scan(dir,found);
        Collections.sort(found,(a,b)->a.getAbsolutePath().length()-b.getAbsolutePath().length());
        return found.isEmpty()?null:found.get(0);
    }
    private void scan(File f,List<File> out) {
        File[] list=f.listFiles(); if(list==null)return;
        for(File x:list) { if(x.isDirectory())scan(x,out); else if(x.getName().toLowerCase(Locale.ROOT).matches(".*\\.(html|htm)$"))out.add(x); }
    }
    private void deleteTree(File f) {
        if(!f.exists())return; File[] c=f.listFiles(); if(c!=null)for(File x:c)deleteTree(x); f.delete();
    }
    private void launchGame(File html) {
        overlay.removeAllViews();
        web.loadUrl(Uri.fromFile(html).toString());
        addControls();
    }
    private void addControls() {
        // Compact translucent controls layered over the running game.
        LinearLayout left=new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); left.setGravity(Gravity.CENTER);
        LinearLayout row1=new LinearLayout(this), row2=new LinearLayout(this); row1.setGravity(Gravity.CENTER); row2.setGravity(Gravity.CENTER);
        row1.addView(keyButton("W","KeyW")); row2.addView(keyButton("A","KeyA")); row2.addView(keyButton("S","KeyS")); row2.addView(keyButton("D","KeyD"));
        left.addView(row1); left.addView(row2);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.LEFT); lp.setMargins(18,0,0,18); overlay.addView(left,lp);

        LinearLayout right=new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setGravity(Gravity.CENTER);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER);
        top.addView(keyButton("ESC","Escape")); top.addView(keyButton("SHIFT","ShiftLeft"));
        right.addView(top);
        Button space=keyButton("SPACE","Space"); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(190,48); sp.topMargin=8; right.addView(space,sp);
        FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.RIGHT); rp.setMargins(0,0,18,18); overlay.addView(right,rp);

        TextView track=text("◎  МЫШЬ",13,Color.WHITE); track.setBackground(bg(0xAA30384F,70));
        track.setPadding(18,18,18,18);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(142,78,Gravity.TOP|Gravity.RIGHT); tp.setMargins(0,18,18,0); overlay.addView(track,tp);
        track.setOnTouchListener((v,e)->{
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN){lastX=x;lastY=y;dragging=true;return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE && dragging) {
                float dx=x-lastX,dy=y-lastY; lastX=x;lastY=y;
                mouseX=Math.max(0,Math.min(1,mouseX+dx/Math.max(1,web.getWidth())));
                mouseY=Math.max(0,Math.min(1,mouseY+dy/Math.max(1,web.getHeight())));
                mouse("mousemove",0); return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP){dragging=false; return true;} return true;
        });
        LinearLayout clicks=new LinearLayout(this); clicks.setOrientation(LinearLayout.VERTICAL);
        LinearLayout cr=new LinearLayout(this);
        cr.addView(mouseButton("ЛКМ",0)); cr.addView(mouseButton("ПКМ",2));
        clicks.addView(cr);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT); cp.setMargins(0,104,18,0); overlay.addView(clicks,cp);
        TextView menu=text("ZIP / МЕНЮ",11,Color.WHITE); menu.setPadding(12,8,12,8); menu.setBackground(bg(0xAA30384F,14));
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT); mp.setMargins(14,14,0,0); overlay.addView(menu,mp);
        menu.setOnClickListener(v->showGameMenu());
    }
    private Button keyButton(String label,String code) {
        Button b=new Button(this); b.setText(label); b.setTextSize(12); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setPadding(8,2,8,2); b.setMinWidth(48); b.setMinimumWidth(48); b.setMinHeight(44);
        b.setBackground(bg(0xBB39445F,14));
        b.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){sendKey(code,true);v.setPressed(true);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){sendKey(code,false);v.setPressed(false);return true;}
            return true;
        });
        return b;
    }
    private Button mouseButton(String label,int button) {
        Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE);
        b.setBackground(bg(0xBB39445F,12)); b.setMinWidth(58);
        b.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){mouse("mousedown",button);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){mouse("mouseup",button);if(e.getAction()==MotionEvent.ACTION_UP)mouse("click",button);return true;}
            return true;
        }); return b;
    }
    private void sendKey(String code,boolean down) {
        String key=code.equals("Space")?" ":code.equals("Escape")?"Escape":code.startsWith("Key")?code.substring(3).toLowerCase(Locale.ROOT):"Shift";
        String js="(function(){let k="+JSONObjectQuote(key)+",c="+JSONObjectQuote(code)+";let t=document.activeElement||document;let e=new KeyboardEvent("+(down?"'keydown'":"'keyup'")+",{key:k,code:c,bubbles:true,cancelable:true});t.dispatchEvent(e);try{let pe=new PointerEvent('pointer'+type.replace('mouse',''),{bubbles:true,cancelable:true,pointerId:1,pointerType:'mouse',clientX:x,clientY:y,button:b});t.dispatchEvent(pe);}catch(_){} })();";
        web.evaluateJavascript(js,null);
    }
    private String JSONObjectQuote(String s) { return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'"; }
    private void mouse(String type,int button) {
        String js="(function(){let x="+(mouseX*web.getWidth())+",y="+(mouseY*web.getHeight())+",b="+button+";let t=document.elementFromPoint(x,y)||document;let e=new MouseEvent('"+type+"',{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y,button:b,buttons:"+(type.equals("mouseup")?0:(button==2?2:1))+"});t.dispatchEvent(e);try{let pe=new PointerEvent('pointer'+type.replace('mouse',''),{bubbles:true,cancelable:true,pointerId:1,pointerType:'mouse',clientX:x,clientY:y,button:b});t.dispatchEvent(pe);}catch(_){} })();";
        web.evaluateJavascript(js,null);
    }
    private void showGameMenu() {
        new android.app.AlertDialog.Builder(this).setTitle("Mobile Game Emulator")
            .setItems(new String[]{"Загрузить другой ZIP","Перезагрузить игру","Вернуться к экрану загрузки"},(d,w)->{
                if(w==0)pickZip(); else if(w==1)web.reload(); else {web.loadUrl("about:blank");showWelcome();}
            }).setNegativeButton("Закрыть",null).show();
    }
    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else showGameMenu();
    }
}
